# Python 项目组织模式 — 从脚本到可安装 CLI 工具

## 1. 项目布局演进

### 单文件脚本
```
agent.py                    ← 一个 .py 文件
```
运行方式：`python agent.py`
关键：`if __name__ == "__main__"` 作为入口

### 多文件包
```
agent/
├── __init__.py             ← 包标识，可以是空文件
├── tools/
│   ├── __init__.py
│   ├── base.py
│   └── read.py
└── loop.py
```
运行方式：`python -m agent.loop` 或 `from agent.tools import BaseTool`

### src layout + pyproject.toml
```
project/
├── pyproject.toml          ← 项目元数据 + 构建 + 工具配置
├── src/
│   └── mypackage/
│       ├── __init__.py
│       ├── cli.py
│       └── ...
└── tests/
```
运行方式：`pip install -e .` → `mypackage` 命令全局可用

### 为什么用 src/ layout？

扁平布局的陷阱：当你在项目根目录运行 `import mypackage`，Python 优先找当前目录的 `mypackage/`，而非 `site-packages/` 中安装的版本。这导致：
- 测试时导入的是源码目录，不是安装包
- 可能发现不了打包配置错误（如缺少 `__init__.py`）
- 开发时和用户使用时行为不一致

src/ layout 强制 `pip install -e .` 后才能导入，确保打包正确。

## 2. pyproject.toml 完整结构

```toml
[build-system]
requires = ["hatchling"]              # 构建后端（hatchling / setuptools / flit / poetry）
build-backend = "hatchling.build"

[project]
name = "my-package"                   # pip install 时的包名
version = "0.1.0"                     # 语义化版本 (MAJOR.MINOR.PATCH)
description = "A short description"
readme = "README.md"
license = "MIT"
requires-python = ">=3.10"
authors = [{ name = "Your Name", email = "you@example.com" }]

dependencies = [                      # 运行时依赖
    "openai>=1.0.0",
    "pydantic>=2.0.0",
]

[project.optional-dependencies]       # 可选依赖组
dev = ["pytest>=8.0.0", "ruff>=0.5.0", "mypy>=1.10.0"]
tui = ["rich>=13.0.0", "textual>=0.80.0"]

[project.scripts]                     # CLI 入口点
my-cmd = "mypackage.cli:app"         # 命令名 = "模块路径:对象名"

[tool.hatch.build.targets.wheel]
packages = ["src/mypackage"]          # 告诉构建后端包在哪

[tool.ruff]
line-length = 100
target-version = "py310"

[tool.mypy]
python_version = "3.10"
strict = true

[tool.pytest.ini_options]
testpaths = ["tests"]
asyncio_mode = "auto"
```

### 关键段说明

| 段 | 作用 | 不写的后果 |
|---|------|----------|
| `[build-system]` | 告诉 pip 用什么构建 | pip 不知道怎么构建 |
| `[project.scripts]` | 注册 CLI 命令 | 安装后没有全局命令 |
| `[project.optional-dependencies]` | 分组依赖 | 所有依赖都装，包括不需要的 |
| `[tool.*]` | 工具配置 | 每次运行工具都要传参数 |

## 3. __main__.py 的作用

```python
# src/mypackage/__main__.py
"""Entry point for `python -m mypackage`."""
from mypackage.cli import app

if __name__ == "__main__":
    app()
```

两种运行方式等价：
- `my-cmd` → 通过 `[project.scripts]` 注册
- `python -m mypackage` → 通过 `__main__.py`

`python -m` 的 `-m` 表示"把后面的名字当作模块运行"。Python 会：
1. 把模块的父目录加入 `sys.path`
2. 查找 `mypackage/__main__.py`
3. 执行它

## 4. pip install -e . 开发模式

```bash
# 普通安装：复制代码到 site-packages/
pip install .

# 开发安装：创建链接到源码目录（改代码立即生效）
pip install -e .

# 带可选依赖组
pip install -e ".[dev]"
pip install -e ".[dev,tui]"
```

开发模式的工作原理：
- 在 `site-packages/` 下创建一个 `.egg-link` 文件指向源码目录
- Python 导入时跟随链接到源码目录
- 修改源码后无需重新安装

## 5. 入口点字符串详解

```toml
[project.scripts]
my-cmd = "mypackage.cli:app"
```

`"mypackage.cli:app"` 是入口点字符串，格式为 `模块路径:对象名`。

pip 安装时会在 `Scripts/`（Windows）或 `bin/`（Linux/Mac）下生成一个脚本：

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re
import sys
from mypackage.cli import app
if __name__ == "__main__":
    sys.argv[0] = re.sub(r'(-script\.pyw|\.exe)?$', '', sys.argv[0])
    sys.exit(app())
```

这就是为什么安装后可以直接在终端输入 `my-cmd` 运行。

## 6. __init__.py 的作用

```python
# src/mypackage/__init__.py

__version__ = "0.1.0"
__all__ = ["Agent", "ToolRegistry", "BaseTool"]  # 控制 from mypackage import * 的内容
```

- `__init__.py` 标识目录为 Python 包
- 可以是空文件，也可以包含包级初始化代码
- `__all__` 控制 `from package import *` 导出的名字
- `py.typed` 文件标记包包含类型提示（mypy 识别）

## 7. 从脚本到项目的演进规律

```
单文件脚本       → 不需要 pyproject.toml，直接 python agent.py
多文件包         → 需要 __init__.py + 相对导入
pip 可安装项目   → 需要 pyproject.toml + src/ layout
CLI 工具        → 需要 [project.scripts] + __main__.py
可发布包         → 需要 README + LICENSE + tests + CI
PyPI 发布       → 需要 twine / hatch build + API token
```

## 8. 常用构建后端对比

| 后端 | 特点 | 适用场景 |
|------|------|---------|
| hatchling | 现代、快速、pyproject.toml 原生 | 通用推荐 |
| setuptools | 最老牌、生态最全 | 兼容旧项目 |
| flit | 极简、适合纯 Python 包 | 小型库 |
| poetry | 依赖管理 + 打包一体化 | 需要锁文件的项目 |
