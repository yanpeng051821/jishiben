#!/usr/bin/env python3
"""
Validate that all chapter code files are syntactically correct and importable.

Usage:
    python validate_code.py /path/to/book/code/directory

Checks:
    1. Each .py file is syntactically valid (ast.parse)
    2. Each chapter directory has a requirements.txt
    3. File naming follows convention: NN_description.py
"""

import ast
import sys
from pathlib import Path


def validate_syntax(py_file: Path) -> tuple[bool, str]:
    """Check if a Python file is syntactically valid."""
    try:
        with open(py_file, "r", encoding="utf-8") as f:
            ast.parse(f.read())
        return True, "OK"
    except SyntaxError as e:
        return False, f"SyntaxError at line {e.lineno}: {e.msg}"
    except UnicodeDecodeError as e:
        return False, f"UnicodeDecodeError: {e}"


def validate_chapter(ch_dir: Path) -> list[str]:
    """Validate a chapter directory."""
    issues = []

    if not ch_dir.is_dir():
        return [f"Not a directory: {ch_dir}"]

    # Check for requirements.txt
    if not (ch_dir / "requirements.txt").exists():
        issues.append("Missing requirements.txt")

    # Validate each .py file
    for py_file in sorted(ch_dir.glob("*.py")):
        if py_file.name.startswith("_"):
            continue

        # Check naming convention
        name = py_file.stem
        if not name[0:2].isdigit():
            issues.append(f"Bad naming: {py_file.name} (should start with NN_)")

        # Check syntax
        ok, msg = validate_syntax(py_file)
        if not ok:
            issues.append(f"{py_file.name}: {msg}")

    return issues


def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_code.py /path/to/book/code/directory")
        sys.exit(1)

    code_dir = Path(sys.argv[1])
    if not code_dir.exists():
        print(f"Path not found: {code_dir}")
        sys.exit(1)

    total_files = 0
    total_issues = 0

    # Find all chapter directories
    ch_dirs = sorted(
        [d for d in code_dir.iterdir() if d.is_dir() and d.name.startswith("ch")],
        key=lambda d: d.name,
    )

    if not ch_dirs:
        print(f"No chapter directories found in {code_dir}")
        sys.exit(1)

    print(f"🔍 Validating code in: {code_dir}\n")

    for ch_dir in ch_dirs:
        py_files = list(ch_dir.glob("*.py"))
        total_files += len(py_files)

        issues = validate_chapter(ch_dir)

        if issues:
            print(f"❌ {ch_dir.name}/ ({len(py_files)} files):")
            for issue in issues:
                print(f"   - {issue}")
                total_issues += 1
        else:
            print(f"✅ {ch_dir.name}/ ({len(py_files)} files): all good")

    print(f"\n📊 Summary: {total_files} files, {total_issues} issues")
    sys.exit(1 if total_issues > 0 else 0)


if __name__ == "__main__":
    main()
