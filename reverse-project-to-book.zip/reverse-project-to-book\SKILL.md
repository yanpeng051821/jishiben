---
name: reverse-project-to-book
description: >
  This skill should be used when the user wants to reverse-engineer an existing software project
  into a progressive tutorial book — "how to build this project from scratch, step by step".
  It provides a complete workflow for analyzing a project's architecture, identifying its
  subsystems, planning a chapter-by-chapter teaching structure where each chapter adds one
  subsystem motivated by a real engineering disaster, and generating runnable code for every
  subsection. Also covers Python project packaging/organization knowledge as a parallel
  teaching thread. Trigger phrases: "把项目变成书", "逆向成书", "从零构建", "项目逆向分析",
  "reverse engineer project into book", "build from scratch tutorial".
---

# Reverse Project to Book — 逆向拆解项目成书

## Purpose

Transform an existing software project into a progressive tutorial book that teaches readers how to build it from scratch. Each chapter introduces one subsystem, motivated by a real engineering disaster ("what happens without this layer"), with runnable code in every subsection.

## When to Use

- User wants to turn an existing project into a "build from scratch" tutorial/book
- User wants to reverse-analyze a project's architecture and teach it progressively
- User wants a structured plan for writing a technical book based on a real project
- User asks about "逆向成书", "项目拆解", "从零构建教学"

## Complete Workflow

### Phase 1: Research & Preparation (2-3 hours)

1. **Clone the target project locally** into a `repos/` directory
2. **Identify reference projects/books** for teaching style (e.g., hello-agents for progressive AI agent tutorials)
3. **Identify reference books for language deep-dives** (e.g., Fluent Python 2nd Ed for Python syntax)
4. **Search for production-grade analysis articles** about similar systems (e.g., Claude Code harness engineering analyses)
5. **Explore the target project's source code structure** using code-explorer subagent — map every directory, key class, and dependency

### Phase 2: Architecture Analysis (1-2 hours)

1. **Map the subsystems**: List every module/package with its responsibility, code lines, key classes
2. **Identify the dependency graph**: Which subsystem depends on which?
3. **Find the minimal viable subset**: What's the smallest set of subsystems needed to run the project?
4. **Extract the natural growth order**: Start from the minimal subset, then add subsystems in dependency order
5. **Document the "disaster story" for each subsystem**: What real-world engineering failure does this subsystem prevent?

### Phase 3: Book Structure Planning (1-2 hours)

1. **Define 4 Phases**: Minimum Runnable → Module Split → Engineering Hardening → Complete Project
2. **Assign chapters to subsystems**: Each chapter = one subsystem, ordered by dependency
3. **Split each chapter into 4-8 subsections**: Each subsection = one runnable code increment
4. **Design the "project organization" parallel thread**: From single-file script → package → pip-installable → CLI tool
5. **Map language deep-dive references**: For each subsection, identify which FP2E (or equivalent) chapter to reference

### Phase 4: Chapter Structure Template

Every chapter follows this structure:

```
1. Disaster Scene (灾难现场) — A real engineering disaster that this subsystem prevents
2. Problem Analysis — What happens without this Harness layer (production evidence)
3. Principle & Design — Formal definition / diagram ("three-step" principle)
4. Build from Zero — Hand-written code ("three-step" component)
5. Language Deep-Dive — Reference FP2E (or equivalent) for key syntax/concepts
6. Pitfalls & Lessons — Anti-patterns, incident-driven stories
7. Source Code Comparison — Our implementation vs. target project's real code
8. Production Comparison — Our simplification vs. production-grade gap
9. Exercises — Hands-on extensions
```

Every subsection follows this structure:

```
Goal → Problem Introduction → Runnable Code → Language Deep-Dive → Exercise
```

### Phase 5: Code Conventions

All code in the book must follow these conventions:

| Convention | Description |
|-----------|-------------|
| Python version | 3.10+ (use `match`, `X \| Y` type syntax) |
| Dependencies | Each chapter starts with `pip install` command |
| API Keys | Use environment variables, never hardcode |
| File structure | Each chapter in independent `code/chXX/` directory |
| Progressive | Each subsection builds on previous, mark new lines with `# NEW` |
| Error handling | All tools catch-all, never let exceptions escape boundaries |
| Type hints | All public function signatures include type hints |

### Phase 6: Python Project Organization Teaching Thread

Parallel to the main content, teach project organization as it naturally evolves:

| Stage | Knowledge Point | When |
|-------|----------------|------|
| Single file script | `if __name__ == "__main__"` | Phase 1 |
| Multi-file package | `__init__.py`, relative imports | Phase 1→2 transition |
| src layout + pyproject.toml | `pip install -e .` development mode | Phase 2→3 transition |
| CLI entry points | `[project.scripts]`, `__main__.py` | Phase 4 |
| Optional dependencies | `[project.optional-dependencies]` | Phase 3 |
| Tool configuration | `[tool.ruff]`, `[tool.mypy]`, `[tool.pytest]` | Phase 3 |

Key concepts to explain in detail:
- **Why src/ layout?** Flat layout imports source directory instead of installed package
- **pyproject.toml line-by-line**: build-system, project metadata, dependencies, scripts, tool config
- **`__main__.py`**: Enables `python -m package_name` execution
- **Entry point string** `"module.path:object"`: How pip generates CLI wrapper scripts
- **`pip install -e .`**: Creates symlink to source directory, changes take effect immediately

## Bundled Resources

### references/

- **`project-organization.md`**: Python project organization patterns — src layout, pyproject.toml, entry points, packaging
- **`harness-engineering.md`**: Harness Engineering core concepts — 5 elements, 3-layer architecture, 5-step auto-correction loop, 6 tradeoffs
- **`teaching-patterns.md`**: Progressive teaching patterns extracted from hello-agents — disaster-driven, three-step, anti-pattern list, freedom spectrum

### scripts/

- **`analyze_project.py`**: Analyze a Python project's directory structure, extract module dependency graph, suggest chapter ordering
- **`validate_code.py`**: Validate that all chapter code files are syntactically correct and importable

## Critical Success Factors

1. **Every subsection's code must run independently** — test each one before writing the next
2. **The disaster story must be real and specific** — not "something might go wrong" but "at Company X on Date Y, this exact failure happened"
3. **Language deep-dives must reference specific book chapters** — not "see FP2E" but "📖 FP2E Chapter 13 'Protocols and ABCs', knowledge point: ..."
4. **Project organization knowledge must be taught in context** — not a separate chapter, but woven into the natural evolution from script to package
5. **The progression must be strictly incremental** — each subsection adds ~20 lines of new code on top of the previous one
