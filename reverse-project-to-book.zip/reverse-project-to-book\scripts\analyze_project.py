#!/usr/bin/env python3
"""
Analyze a Python project's directory structure and suggest chapter ordering.

Usage:
    python analyze_project.py /path/to/project/root

Output:
    - Module list with code line counts
    - Dependency graph (imports between modules)
    - Suggested chapter ordering based on dependency analysis
"""

import ast
import sys
from collections import defaultdict
from pathlib import Path


def count_lines(py_file: Path) -> int:
    """Count non-blank, non-comment lines in a Python file."""
    try:
        with open(py_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        return sum(
            1 for line in lines
            if line.strip() and not line.strip().startswith("#")
        )
    except (UnicodeDecodeError, PermissionError):
        return 0


def extract_imports(py_file: Path, package_name: str) -> list[str]:
    """Extract internal imports (within the package) from a Python file."""
    try:
        with open(py_file, "r", encoding="utf-8") as f:
            tree = ast.parse(f.read())
    except (SyntaxError, UnicodeDecodeError):
        return []

    internal_imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            if node.module.startswith(package_name):
                internal_imports.append(node.module)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith(package_name):
                    internal_imports.append(alias.name)
    return internal_imports


def analyze_project(root: Path) -> dict:
    """Analyze project structure and return metrics."""
    # Find the main package directory under src/ or root
    src_dir = root / "src"
    if src_dir.exists():
        packages = [d for d in src_dir.iterdir() if d.is_dir() and (d / "__init__.py").exists()]
    else:
        packages = [d for d in root.iterdir() if d.is_dir() and (d / "__init__.py").exists()]

    if not packages:
        print("No Python packages found.")
        return {}

    main_pkg = packages[0]
    pkg_name = main_pkg.name

    # Analyze each subpackage / module
    modules = {}
    dep_graph = defaultdict(list)

    for py_file in sorted(main_pkg.rglob("*.py")):
        rel_path = py_file.relative_to(main_pkg)
        module_path = str(rel_path.with_suffix("")).replace("\\", ".").replace("/", ".")

        line_count = count_lines(py_file)
        imports = extract_imports(py_file, pkg_name)

        modules[module_path] = {
            "file": str(rel_path),
            "lines": line_count,
            "imports": imports,
        }
        for imp in imports:
            dep_graph[module_path].append(imp)

    return {
        "package_name": pkg_name,
        "package_path": str(main_pkg),
        "modules": modules,
        "dep_graph": dict(dep_graph),
        "total_lines": sum(m["lines"] for m in modules.values()),
    }


def suggest_chapter_order(analysis: dict) -> list[str]:
    """Suggest chapter ordering based on dependency analysis (topological sort)."""
    modules = analysis["modules"]
    dep_graph = analysis["dep_graph"]

    # Find modules that are depended on most (core modules)
    reverse_deps = defaultdict(int)
    for mod, deps in dep_graph.items():
        for dep in deps:
            reverse_deps[dep] += 1

    # Sort by: most depended-on first, then by code size (larger = more complex = later)
    sorted_mods = sorted(
        modules.keys(),
        key=lambda m: (-reverse_deps.get(m, 0), modules[m]["lines"]),
    )

    return sorted_mods


def main():
    if len(sys.argv) < 2:
        print("Usage: python analyze_project.py /path/to/project/root")
        sys.exit(1)

    root = Path(sys.argv[1])
    if not root.exists():
        print(f"Path not found: {root}")
        sys.exit(1)

    analysis = analyze_project(root)
    if not analysis:
        sys.exit(1)

    print(f"\n📦 Package: {analysis['package_name']}")
    print(f"📍 Path: {analysis['package_path']}")
    print(f"📊 Total lines: {analysis['total_lines']}")
    print(f"\n{'Module':<40} {'Lines':>6} {'Deps':>5}")
    print("-" * 55)

    for mod, info in sorted(analysis["modules"].items(), key=lambda x: -x[1]["lines"]):
        dep_count = len(info["imports"])
        print(f"{mod:<40} {info['lines']:>6} {dep_count:>5}")

    print("\n\n📖 Suggested chapter order (most-depended-on first):")
    order = suggest_chapter_order(analysis)
    for i, mod in enumerate(order, 1):
        lines = analysis["modules"][mod]["lines"]
        deps = analysis["dep_graph"].get(mod, [])
        print(f"  Ch{i:>2}. {mod:<40} ({lines} lines, depends on: {', '.join(deps) or 'none'})")


if __name__ == "__main__":
    main()
